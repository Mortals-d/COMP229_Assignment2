module.exports = {

    //url: "mongodb://localhost:27017/Blessing_db"  
  
    //ATLAS_URI=mongodb + srv://Blessing:crLlpnzOKuPjUPvz@cluster0.pzwkbe4.mongodb.net/tutorials?retryWrites=true&w=majority;
  
     //url:"mongodb+srv://Blessing:crLlpnzOKuPjUPvz@cluster0.pzwkbe4.mongodb.net/Tutorial?retryWrites=true&w=majority"
  
  url:"mongodb+srv://dhb061:0dJyKEraleV9bLtd@cluster0.vfunzei.mongodb.net/SportStore?retryWrites=true&w=majority"
  
  };